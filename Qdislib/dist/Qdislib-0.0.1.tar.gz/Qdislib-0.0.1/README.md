# Qdislib - Quantum Distributed Computing Library


This is a simple example readme.

This library provides a distributed computing version of the quantum circuit cutting algorithm.


### Requirements

- Python >= 3.10
